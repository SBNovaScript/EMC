<!-- This is included on the home page to make the nice looking word blocks -->

<div id="EII_bar">
<h1 class="big_text">
	 <?php echo get_theme_mod( 'tagline1'); ?>
</h1>
<a class="word" id="block1" href="#">EMERGE</a>
<a class="word" id="block2" href="#">INNOVATE</a>
<a class="word" id="block3" href="#">INSPIRE</a>
</div>