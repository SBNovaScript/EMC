( function( $ ) {

wp.customize( 'tagline2', function( value ) {
    value.bind( function( newVal ) {
      $( 'h1' ).text( "will you appear!" );
    } );
  } );

} )( jQuery );