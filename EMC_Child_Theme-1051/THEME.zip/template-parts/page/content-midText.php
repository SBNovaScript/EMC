<div class="midText">
<h1><?php the_sub_field('header');?></h1>
<?php the_sub_field('text');?>
</div>