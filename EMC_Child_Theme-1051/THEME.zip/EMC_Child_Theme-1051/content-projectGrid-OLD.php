<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


<div class="container-fluid projects-page"> 
	<h1>Projects:</h1>
	<div class="row">
	<div class="col-sm-4">
		<img src="http://www.wellcomeimageawards.org/jpegs/58956/B0010980_main.jpg"> 
		<h2>Project 1</h2>
		<p>
		Tip: Go to our CSS Responsive Web Design Tutorial to learn more about responsive web design and grids.
		</p>
	</div>

	<div class="col-sm-4">
		<img src="http://www.wellcomeimageawards.org/jpegs/58956/B0010980_main.jpg">
		<h2>Project 1</h2>
		<p>
		Tip: Go to our CSS Responsive Web Design Tutorial to learn more about responsive web design and grids.
		</p>
	</div>

	<div class="col-sm-4">
		<img src="http://www.wellcomeimageawards.org/jpegs/58956/B0010980_main.jpg">
		<h2>Project 1</h2>
		<p>
		Tip: Go to our CSS Responsive Web Design Tutorial to learn more about responsive web design and grids.
		</p>
	</div>
	</div>

	<div class="row">
		<div class="col-sm-4">
			<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ87qapmgUogqbOOZpe8vOy6S62cMXaz6ly9UJJwUfkQaY01GTf0Q">
			<h2>Project 1</h2>
			<p>
			Tip: Go to our CSS Responsive Web Design Tutorial to learn more about responsive web design and grids.
			</p>
		</div>

		<div class="col-sm-4">
			<img src="http://www.wellcomeimageawards.org/jpegs/58956/B0010980_main.jpg">
			<h2>Project 1</h2>
			<p>
			Tip: Go to our CSS Responsive Web Design Tutorial to learn more about responsive web design and grids.
			</p>
		</div>

		<div class="col-sm-4">
			<img src="http://www.wellcomeimageawards.org/jpegs/58956/B0010980_main.jpg">
			<h2>Project 1</h2>
			<p>
			Tip: Go to our CSS Responsive Web Design Tutorial to learn more about responsive web design and grids.
			</p>
		</div>
	</div>

	<div class="row">
		<div class="col-sm-4">
			<img src="http://www.wellcomeimageawards.org/jpegs/58956/B0010980_main.jpg">
			<h2>Project 1</h2>
			<p>
			Tip: Go to our CSS Responsive Web Design Tutorial to learn more about responsive web design and grids.
			</p>
		</div>

		<div class="col-sm-4">
			<img src="http://www.wellcomeimageawards.org/jpegs/58956/B0010980_main.jpg">
			<h2>Project 1</h2>
			<p>
			Tip: Go to our CSS Responsive Web Design Tutorial to learn more about responsive web design and grids.
			</p>
		</div>

		<div class="col-sm-4">
			<img src="http://www.wellcomeimageawards.org/jpegs/58956/B0010980_main.jpg">
			<h2>Project 1</h2>
			<p>
			Tip: Go to our CSS Responsive Web Design Tutorial to learn more about responsive web design and grids.
			</p>
		</div>

	</div>