<div id="pink_block">
<div id="pink_block_content">
  <h1 class="big_text2"> <?php echo get_theme_mod( 'tagline2'); ?> </h1>
  <a href="#">About Us / Our Work</a>
  </div>
</div>