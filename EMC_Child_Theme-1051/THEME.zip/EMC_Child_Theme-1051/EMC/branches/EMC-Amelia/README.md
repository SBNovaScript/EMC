# EMC
This is the GitHub EMC Website repository. All theme files can be found under the main "EMC_Child_Theme-1051" folder.