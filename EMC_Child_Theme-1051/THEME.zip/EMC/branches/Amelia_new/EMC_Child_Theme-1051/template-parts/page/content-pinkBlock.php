<div id="pink_block" style = "background-color: <?php  the_sub_field('pink_block_background_color');?>; ">
<div id="pink_block_content" >
  <h1 class="big_text2" style = "color: <?php the_sub_field('pinkBlock_text_color');?>;"> 
  <?php  the_sub_field('pink_block_text'); ?> </h1>
  
  <a href="<?php the_sub_field(pinkBlock_linklocation)?>" style = "color: <?php the_sub_field('pinkBlock_text_color');?>;" ><?php the_sub_field(PinkBlock_linktext)?></a>
  </div>
</div>