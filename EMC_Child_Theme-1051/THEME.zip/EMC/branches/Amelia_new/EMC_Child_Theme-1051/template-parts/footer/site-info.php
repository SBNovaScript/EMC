<?php
/**
 * Displays footer site info
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?>

<div class="footer">
    <div class="fixed-col">
          <h2><a href="#">Contact Us</a></h2>
      <a href="#">Ketri Tracy,</a> 
      Busness devlopment manager, 
      Emergent Media Center,
      Champlain College<br> 
      802-856-8438<br>
      <a href ="#"> ktracy@champlain.edu</a>
    </div>
    
    <div class="varible-col">
      <img src="https://imageog.flaticon.com/icons/png/512/54/54076.png?size=1200x630f&pad=10,10,10,10&ext=png&bg=FFFFFFFF">
    </div>
    
    <div class="fixed-col final-item">
    <h2><a href="#">Partnerships</a></h2>
      <a href="#">Test test test test def</a><br>
      <a href="#">Test test test test rff</a><br>
      <a href="#">Test test test test test</a><br>
      <a href="#">Test test test test stuff</a><br>
    </div>
</div>
<!--	<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'twentyseventeen' ) ); ?>"><?php printf( __( 'Copyright Emergent Media Center 2017' ) ); ?></a>-->
